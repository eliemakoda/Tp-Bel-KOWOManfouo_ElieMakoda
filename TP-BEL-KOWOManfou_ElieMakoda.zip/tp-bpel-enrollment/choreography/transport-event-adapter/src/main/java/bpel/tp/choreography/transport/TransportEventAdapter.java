package bpel.tp.choreography.transport;

import bpel.tp.transport.TransportServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableJms
public class TransportEventAdapter {
  public static void main(String[] a) { SpringApplication.run(TransportEventAdapter.class, a); }

  @Bean
  public TransportServiceImpl transport() { return new TransportServiceImpl(); }
}
