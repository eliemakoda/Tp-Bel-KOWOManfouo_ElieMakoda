package bpel.tp.choreography.bank;

import bpel.tp.bank.BankServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableJms
public class BankEventAdapter {
  public static void main(String[] a) { SpringApplication.run(BankEventAdapter.class, a); }

  @Bean
  public BankServiceImpl bank() { return new BankServiceImpl(); }
}
