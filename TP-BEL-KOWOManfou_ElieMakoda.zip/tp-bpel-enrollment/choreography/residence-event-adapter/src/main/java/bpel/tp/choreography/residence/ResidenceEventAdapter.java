package bpel.tp.choreography.residence;

import bpel.tp.residence.ResidenceServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableJms
public class ResidenceEventAdapter {
  public static void main(String[] a) { SpringApplication.run(ResidenceEventAdapter.class, a); }

  @Bean
  public ResidenceServiceImpl residence() { return new ResidenceServiceImpl(); }
}
