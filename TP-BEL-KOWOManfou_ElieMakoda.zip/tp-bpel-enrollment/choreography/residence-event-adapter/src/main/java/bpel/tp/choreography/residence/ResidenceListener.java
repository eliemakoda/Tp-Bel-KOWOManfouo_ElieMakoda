package bpel.tp.choreography.residence;

import bpel.tp.residence.AssignRequest;
import bpel.tp.residence.AssignResponse;
import bpel.tp.residence.ResidenceServiceImpl;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
class ResidenceListener {
  @Autowired private JmsTemplate jms;
  @Autowired private ResidenceServiceImpl residence;

  private final Map<String, Event> rooms  = new ConcurrentHashMap<>();
  private final Map<String, Event> passes = new ConcurrentHashMap<>();

  @JmsListener(destination = "PaymentDecided")
  public void onPaymentDecided(String json) throws Exception {
    Event e = Event.parse(json);
    if (!e.data.get("approved").asBoolean()) return;
    AssignResponse r = residence.assignRoom(new AssignRequest(
        e.data.get("studentId").asText()));

    Event out = Event.of("RoomAssigned", e.correlationId,
        Map.of("studentId",  e.data.get("studentId").asText(),
               "roomNumber", r.getRoomNumber(),
               "receipt",    e.data.get("receipt").asText()));
    jms.convertAndSend("RoomAssigned", out.toJson());
  }

  @JmsListener(destination = "RoomAssigned")
  public void onRoomAssigned(String json) throws Exception {
    Event e = Event.parse(json);
    rooms.put(e.correlationId, e);
    complete(e.correlationId);
  }

  @JmsListener(destination = "PassActivated")
  public void onPassActivated(String json) throws Exception {
    Event e = Event.parse(json);
    passes.put(e.correlationId, e);
    complete(e.correlationId);
  }

  private synchronized void complete(String correlationId) throws Exception {
    Event room = rooms.get(correlationId);
    Event pass = passes.get(correlationId);
    if (room == null || pass == null) return;
    rooms.remove(correlationId);
    passes.remove(correlationId);
    if (!Instant.parse(room.timestamp).isAfter(Instant.parse(pass.timestamp))) return;

    Event out = Event.of("EnrollmentCompleted", correlationId,
        Map.of("studentId",  room.data.get("studentId").asText(),
               "status",     "ENROLLED",
               "roomNumber", room.data.get("roomNumber").asText(),
               "passId",     pass.data.get("passId").asText(),
               "receipt",    room.data.get("receipt").asText()));
    jms.convertAndSend("EnrollmentCompleted", out.toJson());
  }
}
