package bpel.tp.choreography.university;

import bpel.tp.university.UniversityServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableJms
public class UniversityEventAdapter {
  public static void main(String[] a) { SpringApplication.run(UniversityEventAdapter.class, a); }

  @Bean
  public UniversityServiceImpl university() { return new UniversityServiceImpl(); }
}
