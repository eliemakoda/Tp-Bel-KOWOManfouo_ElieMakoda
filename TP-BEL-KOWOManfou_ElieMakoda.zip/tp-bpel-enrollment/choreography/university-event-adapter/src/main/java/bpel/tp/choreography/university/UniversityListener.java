package bpel.tp.choreography.university;

import bpel.tp.university.CancelRequest;
import bpel.tp.university.RegisterRequest;
import bpel.tp.university.RegisterResponse;
import bpel.tp.university.Student;
import bpel.tp.university.UniversityServiceImpl;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
class UniversityListener {
  @Autowired private JmsTemplate jms;
  @Autowired private UniversityServiceImpl university;

  @JmsListener(destination = "EnrollmentRequested")
  public void onEnrollmentRequested(String json) throws Exception {
    Event e = Event.parse(json);
    RegisterResponse r = university.register(new RegisterRequest(new Student(
        e.data.get("student").get("name").asText(),
        e.data.get("student").get("program").asText())));

    Event out = Event.of("StudentRegistered", e.correlationId,
        Map.of("studentId", r.getStudentId(),
               "amount",    e.data.get("amount").asText()));
    jms.convertAndSend("StudentRegistered", out.toJson());
  }

  @JmsListener(destination = "PaymentDecided")
  public void onPaymentDecided(String json) throws Exception {
    Event e = Event.parse(json);
    if (e.data.get("approved").asBoolean()) return;
    university.cancel(new CancelRequest(e.data.get("studentId").asText()));

    Event out = Event.of("EnrollmentCompleted", e.correlationId,
        Map.of("studentId", e.data.get("studentId").asText(),
               "status",    "REFUSED"));
    jms.convertAndSend("EnrollmentCompleted", out.toJson());
  }
}
