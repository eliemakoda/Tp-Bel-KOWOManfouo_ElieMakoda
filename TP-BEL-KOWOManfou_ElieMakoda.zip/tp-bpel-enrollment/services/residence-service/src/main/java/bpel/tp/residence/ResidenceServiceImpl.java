package bpel.tp.residence;

import java.util.concurrent.atomic.AtomicInteger;
import javax.jws.WebService;

@WebService(
  serviceName       = "ResidenceService",
  portName          = "ResidencePort",
  endpointInterface = "bpel.tp.residence.ResidencePT",
  targetNamespace   = "http://tp.bpel/residence/",
  wsdlLocation      = "WEB-INF/wsdl/residence.wsdl"
)
public class ResidenceServiceImpl implements ResidencePT {
    private static final AtomicInteger COUNTER = new AtomicInteger(100);

    @Override public AssignResponse assignRoom(AssignRequest req) {
        AssignResponse r = new AssignResponse();
        r.setRoomNumber("ROOM-" + COUNTER.incrementAndGet());
        return r;
    }
}
