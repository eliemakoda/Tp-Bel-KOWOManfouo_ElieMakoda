package bpel.tp.university;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import javax.jws.WebService;

@WebService(
  serviceName       = "UniversityService",
  portName          = "UniversityPort",
  endpointInterface = "bpel.tp.university.UniversityPT",
  targetNamespace   = "http://tp.bpel/university/",
  wsdlLocation      = "WEB-INF/wsdl/university.wsdl"
)
public class UniversityServiceImpl implements UniversityPT {
    private static final AtomicInteger COUNTER = new AtomicInteger(10000);
    private static final Map<String, Student> STUDENTS = new ConcurrentHashMap<>();

    @Override public RegisterResponse register(RegisterRequest req) {
        String studentId = "STU-" + COUNTER.incrementAndGet();
        STUDENTS.put(studentId, req.getStudent());
        System.out.println("Student " + studentId + " registered");
        RegisterResponse r = new RegisterResponse();
        r.setStudentId(studentId);
        return r;
    }

    @Override public void cancel(CancelRequest req) {
        STUDENTS.remove(req.getStudentId());
        System.out.println("Student " + req.getStudentId() + " cancelled");
    }
}
