package bpel.tp.transport;

import java.util.UUID;
import javax.jws.WebService;

@WebService(
  serviceName       = "TransportService",
  portName          = "TransportPort",
  endpointInterface = "bpel.tp.transport.TransportPT",
  targetNamespace   = "http://tp.bpel/transport/",
  wsdlLocation      = "WEB-INF/wsdl/transport.wsdl"
)
public class TransportServiceImpl implements TransportPT {
    @Override public ActivateResponse activatePass(ActivateRequest req) {
        ActivateResponse r = new ActivateResponse();
        r.setPassId("PASS-" + UUID.randomUUID());
        return r;
    }
}
